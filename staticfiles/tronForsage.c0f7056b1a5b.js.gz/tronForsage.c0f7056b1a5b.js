


var some = $('.test').text(100);
console.log(some,'im hshadhashdj')

// var someadd = $('.sc-fFSRdu').text();
// console.log(someadd,'im hhehehe')


// window.ethereum.enable()